This is the a part of IBM project Watson and it has been built using Apache Lucene with the help of Java. In addition to this it uses stanford corenlp. This is a menu drivern program.

Run the main method and follow the instructions. The best configuration is already pre-setted inside the code.

Any option that you will pick will do indexing and searching together automatically.

Implemented supervised learning using GloVe: Global Vectors for Word Representation.

Implemented the improvement by two methods, of which the BM25 tuning works better.

MRR of the best case is : 0.3834
